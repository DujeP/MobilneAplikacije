//
//  ContentView.swift
//  MobilniProjekt
//
//  Created by Duje Popovic on 29.03.2023..
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack {
                /*NavigationLink(destination: AddRateUs()) {
                    LabeledContent("Navigate") {
                        Image(systemName: "chevron.right")
                        
                    }
                    .padding(.vertical, 12)
                    .padding(.horizontal, 12)
                    .foregroundColor(.black)
                }
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(.white)
                )
                .padding()*/
                Form {
                    Section {
                        NavigationLink {
                            AddMealData()
                        } label: {
                            Text("Enter meal data")
                        }
                        
                        NavigationLink {
                            AddExerciseData()
                        } label: {
                            Text("Enter training data")
                        }
                    } header: {
                        Text("Please enter the calory data")
                    }
                    Section {
                        NavigationLink {
                            ShowDataView()
                        } label: {
                            Text("Data history")
                        }
                    } header: {
                        Text("See history of your data")
                    }
                    /*AsyncImage(url: URL(string: "https://www.macworld.com/wp-content/uploads/2023/01/how-to-use-apple-health-main2.png?w=1024")) { image in
                        image
                            .resizable()
                            .scaledToFit()
                            //.frame(width: 450, height: 210)
                            .clipShape(RoundedRectangle(cornerRadius: 30))
                            .overlay(
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(.white.opacity(0.5))
                            )
                    } placeholder: {
                        ProgressView()
                    }
                    .frame(width: 450, height: 210)//ode je lipse iz nekog razloga*/
                    
                    Image("FrontPagePic")
                        .resizable()
                        .scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 30))
                        .overlay(
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(.white.opacity(0.5))
                        )
                        .frame(width: 450, height: 210)
                }

                
                Rectangle()//a s ovim smo samo dodali ova malu crtu izmedu teksta i slika astronauta
                    .frame(height: 2)
                    .foregroundColor(.lightBackground)
                    .padding(.vertical, -10)
                
                
                HStack {
                    Spacer()
                    NavigationLink {
                        AddRateUs()
                    } label: {
                        Text("Rate us")
                    }
                    Spacer()
                    Spacer()
                    NavigationLink {
                        ShowReviewView()
                    } label: {
                        Text("Reviews")
                    }
                    Spacer()
                    Spacer()
                    NavigationLink {
                        AddAboutUs()
                    } label: {
                        Text("About us")
                    }
                    Spacer()
                }.padding(.bottom)
                Text("For every download You do we donate 1$ to rebuilding the Death Star. Glory to the empire! 🫡")
                    .foregroundColor(.secondary)
                    .font(.callout)
                    .padding([.leading, .bottom, .trailing])
            }
            .scrollContentBackground(.hidden)//ovo da makne cilu pozadinu od forme
            .background(.darkBackground)
            .navigationTitle("Health App")
            .preferredColorScheme(.dark)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
