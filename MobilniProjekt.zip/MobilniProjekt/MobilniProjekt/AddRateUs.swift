//
//  AddRateUs.swift
//  MobilniProjekt
//
//  Created by Duje Popovic on 29.03.2023..
//

import SwiftUI

struct AddRateUs: View {
    
    @Environment(\.managedObjectContext) var moc
    @Environment(\.dismiss) var dismiss
    
    @State private var rating: Int16 = 3
    @State private var timeUsage: Int16 = 0
    @State private var u18 = false
    @State private var source = "Friend"
    @State private var review = ""
    
    let sources = ["Family", "Friend", "School", "Work", "Online", "Advertisment"]
    
    @State private var showAlert: Bool = false
    @State private var titleAlert = ""
    @State private var messageAlert = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("How long have you been using our app(in days approximately)?")
                            .font(.headline)
                        
                        TextField("Days", value: $timeUsage, format: .number)
                            .keyboardType(.decimalPad)
                    }
                    
                    VStack(alignment: .leading, spacing: 0) {
                        Picker("How did you find out about us?", selection: $source) {
                            ForEach(sources, id: \.self) {
                                Text($0)
                            }
                        }
                    }
                }
                
                Section {
                    VStack(alignment: .leading, spacing: 0) {
                        TextEditor(text: $review)
                    }
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Rate us")
                            .opacity(0.75)
                        RatingView(rating: $rating)
                    }
                    
                } header: {
                    Text("Write about what would you change")
                        //.padding(.top, 30) za pomaknit sekciju
                }
                
                VStack(alignment: .leading, spacing: 12) {
                    Button("Save review") {
                        errorMessages(title: "Save review", message: "Are you sure you want to save the data?")
                    }
                }
            }
            .scrollContentBackground(.hidden)//ovo da makne cilu pozadinu od forme
            .background(.darkBackground)
            .preferredColorScheme(.dark)
            .navigationTitle("Tell us..")
            .navigationBarTitleDisplayMode(.inline)
            .alert(titleAlert, isPresented: $showAlert) {
                Button("Cancel", role: .cancel) {} //da smo ode stavili destructive onda bi se pojavija jos jedan cancel botun
                Button("Save", role: .none, action: saveData)
            } message: {
                Text(messageAlert)
            }
        }
    }
    func errorMessages(title: String, message: String) {//funkcija za alert
        titleAlert = title
        messageAlert = message
        showAlert = true
    }
    
    func saveData() {
        let newEntry = Review(context: moc)
        
        newEntry.id = UUID()
        newEntry.review = review
        newEntry.ratings = rating
        newEntry.dateOfEntry = Date.now
        
        try? moc.save()
        
        dismiss()
    }
}

struct AddRateUs_Previews: PreviewProvider {
    static var previews: some View {
        AddRateUs()
    }
}
