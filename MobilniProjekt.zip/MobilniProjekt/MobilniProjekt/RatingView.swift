//
//  RatingView.swift
//  MobilniProjekt
//
//  Created by Duje Popovic on 29.03.2023..
//

import SwiftUI

struct RatingView: View {
    @Binding var rating: Int16
    
    var maximumRating = 6
    
    var colorYellow = Color.yellow
    var colorGrey = Color.gray
    
    var body: some View {
        HStack {
            ForEach(1..<maximumRating, id: \.self) { number in
                Image(systemName: "star.fill")
                    .foregroundColor(number > rating ? colorGrey : colorYellow)
                    .onTapGesture {
                        rating = Int16(number)
                    }
            }
        }
    }
}

struct RatingView_Previews: PreviewProvider {
    static var previews: some View {
        RatingView(rating: .constant(3))//ode smo morali staviti .constant jer kad smo isli bindati onda je blokalo. Baca gresku. Prije nego sta smo isli bindati varijablu onda je radilo sa samo rating: 3
    }
}
