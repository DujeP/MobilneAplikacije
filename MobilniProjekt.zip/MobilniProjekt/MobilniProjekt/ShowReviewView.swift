//
//  ShowReviewView.swift
//  MobilniProjekt
//
//  Created by Duje Popovic on 06.04.2023..
//

import SwiftUI

struct ShowReviewView: View {
    
    @Environment(\.managedObjectContext) var moc
    @Environment(\.dismiss) var dismiss
    
    @FetchRequest(sortDescriptors: [SortDescriptor(\.dateOfEntry, order: .reverse)]) var reviews: FetchedResults<Review>
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack {
                    Text("We read all your reviews and we are working very hard to make everyone happy! 🤗")
                        .padding(12) // mogli smo i ovako
                        //.frame(width: 80, height: 35)
                        .background(.black.opacity(0.5))
                        .foregroundColor(.white.opacity(0.9))
                        .font(.headline)
                        .clipShape(RoundedRectangle(cornerRadius: 30))
                        .overlay(//sa overlayon smo dodali ovu vanjsku kocku koja obuhvaca svaku sliku sa tekstom ispod.
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(.white.opacity(0.5))
                        )
                }.padding([.horizontal, .top], 15)
                
                /*Rectangle()
                    .frame(height: 2)
                    .foregroundColor(.lightBackground)
                    .padding(.vertical)*/
                
                ForEach(reviews) { review in
                    
                    Rectangle()
                        .frame(height: 2)
                        .foregroundColor(.lightBackground)
                        .padding(.vertical)
                    
                    LazyVStack(alignment: .leading) {
                        Text(review.review ?? "No Review")
                            .padding(5)
                        Text(review.dateOfEntry?.formatted(date: .abbreviated, time: .omitted) ?? "N/A")
                            .padding(5)
                        RatingView(rating: .constant(review.ratings))//sa ovin constant smo ga zamrzli tako da se vise nemoze minjati.
                            .font(.largeTitle)
                    }
                    .padding([.leading, .bottom], 20)
                }
            }
            .frame(maxWidth: .infinity)
            .navigationTitle("Reviews")
            //.navigationBarTitleDisplayMode(.inline)
            .foregroundColor(.white)
            .background(.darkBackground)
            .preferredColorScheme(.dark)
        }
    }
}

struct ShowReviewView_Previews: PreviewProvider {
    static var previews: some View {
        ShowReviewView()
    }
}
