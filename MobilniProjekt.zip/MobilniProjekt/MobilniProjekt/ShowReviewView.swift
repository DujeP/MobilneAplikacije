//
//  ShowReviewView.swift
//  MobilniProjekt
//
//  Created by Duje Popovic on 06.04.2023..
//

import SwiftUI

struct ShowReviewView: View {
    
    @Environment(\.managedObjectContext) var moc
    @Environment(\.dismiss) var dismiss
    
    @FetchRequest(sortDescriptors: [SortDescriptor(\.dateOfEntry, order: .reverse)]) var reviews: FetchedResults<Review>
    
    var body: some View {
        NavigationView {
            List {
                ForEach(reviews) { review in
                    VStack(alignment: .leading) {
                        Text(review.review ?? "No Review")
                            .padding(5)
                        Text(review.dateOfEntry?.formatted(date: .abbreviated, time: .omitted) ?? "N/A")
                            .padding(5)
                        RatingView(rating: .constant(review.ratings))//sa ovin constant smo ga zamrzli tako da se vise nemoze minjati.
                            .font(.largeTitle)
                    }
                }
            }
            .navigationTitle("Reviews")
            .background(.darkBackground)
            .preferredColorScheme(.dark)
        }
    }
}

struct ShowReviewView_Previews: PreviewProvider {
    static var previews: some View {
        ShowReviewView()
    }
}
