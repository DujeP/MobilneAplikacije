//
//  FilteredList.swift
//  MobilniProjekt
//
//  Created by Duje Popovic on 04.04.2023..
//

import SwiftUI

struct FilteredList: View {
    
    @FetchRequest var fetchRequest: FetchedResults<Exercise>
    
    var body: some View {
        List(fetchRequest, id: \.self) { exercise in
            Text("\(exercise)")
        }
    }
    init(filter: String) {
        _fetchRequest = FetchRequest<Exercise>(sortDescriptors: [], predicate: NSPredicate(format: "dateOfEntry == %@", filter))
    }
}
