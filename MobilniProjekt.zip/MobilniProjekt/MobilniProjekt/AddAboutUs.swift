//
//  AddAboutUs.swift
//  MobilniProjekt
//
//  Created by Duje Popovic on 29.03.2023..
//

import SwiftUI

struct AddAboutUs: View {
    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                ScrollView(showsIndicators: false) {
                    ZStack(alignment: .bottomLeading) {
                        AsyncImage(url: URL(string: "https://i.pinimg.com/280x280_RS/51/b9/47/51b9475962632c1616600ef74a266aa1.jpg")) { image in
                            image
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: geometry.size.width * 0.8)
                                .clipShape(RoundedRectangle(cornerRadius: 30))
                                .overlay(//sa overlayon smo dodali ovu vanjsku kocku koja obuhvaca svaku sliku sa tekstom ispod.
                                    RoundedRectangle(cornerRadius: 30)
                                        .stroke(.white.opacity(0.5))
                                )
                        } placeholder: {
                            ProgressView()
                        }
                        Text("Duje Popović")
                            .font(.caption)
                            .fontWeight(.black)
                            .padding(8)
                            .foregroundColor(.white)
                            .background(.black.opacity(0.75))
                            .clipShape(Capsule())
                            .padding(.leading, 10)
                            .padding(.bottom, 5)
                    }.padding(.bottom)
                    
                    Text("""
                         My name is Duje Popović and I am the creator of this fantastic application. I still dont know how I managed to make everything work or why it even works, but I guess that's one of those life mysteries...
                         
                         Anyways the application can store your data inside a database, it can read the history of your entered data, you have options to rate us and read about our company and in the near future there will be more updates..
                         
                         Only time will tell. But in any case thank you for being part of the journey.
                         """).padding()
                }
            }
            .navigationTitle("About us")
            .navigationBarTitleDisplayMode(.inline)
            .foregroundColor(.white)
            .background(.darkBackground)
            .preferredColorScheme(.dark)
        }
    }
}

struct AddAboutUs_Previews: PreviewProvider {
    static var previews: some View {
        AddAboutUs()
    }
}
