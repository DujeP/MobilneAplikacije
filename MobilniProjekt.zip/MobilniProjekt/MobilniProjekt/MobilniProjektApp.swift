//
//  MobilniProjektApp.swift
//  MobilniProjekt
//
//  Created by Duje Popovic on 29.03.2023..
//

import SwiftUI

@main
struct MobilniProjektApp: App {
    
    @State private var dataController = DataController()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, dataController.container.viewContext)
        }
    }
}
