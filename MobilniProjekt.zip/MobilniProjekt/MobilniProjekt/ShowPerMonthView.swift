//
//  ShowPerMonthView.swift
//  MobilniProjekt
//
//  Created by Duje Popovic on 06.04.2023..
//

import SwiftUI

struct ShowPerMonthView: View {
    
    @Environment(\.managedObjectContext) var moc
    @Environment(\.dismiss) var dismiss
    
    @FetchRequest(sortDescriptors: [SortDescriptor(\.dateOfEntry, order: .reverse)], predicate: nil) var foods: FetchedResults<Food>
    @FetchRequest(sortDescriptors: [SortDescriptor(\.dateOfEntry, order: .reverse)], predicate: nil) var exercises: FetchedResults<Exercise>
    
    let monthsList = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    @State private var monthPick: String = currentMonth()
    
    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                ScrollView {
                    HStack {
                        Text("Pick a month: ")
                        Picker("Pick a month", selection: $monthPick) {
                            ForEach(monthsList, id: \.self) {
                                Text($0)
                            }
                        }
                        .pickerStyle(.menu)
                    }
                    .padding(.top, 20)
                    
                    Rectangle()
                        .frame(height: 2)
                        .foregroundColor(.lightBackground)
                        .padding(.vertical)
                    
                    LazyVStack(alignment: .leading, spacing: 30) {//izgleda kad se stavi lazy onda se samo od sebe namisti lipo
                        Text("Total calories taken in: \(addCalories())")
                        Text("Total time trained: \(addTime())")
                        Text("Number of exercises done: \(exerciseCount())")
                        Text("Exercises done: \(exerciseList())")
                    }
                    .font(.headline)
                    .padding()
                    
                    Rectangle()
                        .frame(height: 2)
                        .foregroundColor(.lightBackground)
                        .padding(.vertical)
                    
                    /*AsyncImage(url: URL(string: "https://i.pinimg.com/736x/f5/d7/82/f5d7822bcfde665cde96eab539a8c410--fitness-humor-fitness-nutrition.jpg")) { image in
                        image
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: geometry.size.width * 0.8)
                            .clipShape(RoundedRectangle(cornerRadius: 30))
                            .overlay(//sa overlayon smo dodali ovu vanjsku kocku koja obuhvaca svaku sliku sa tekstom ispod.
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(.white.opacity(0.5))
                            )
                    } placeholder: {
                        ProgressView()
                    }*/
                    //.padding(.vertical, 50)
                    
                    Image("StatisticsPic")
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: geometry.size.width * 0.8)
                        .clipShape(RoundedRectangle(cornerRadius: 30))
                        .overlay(//sa overlayon smo dodali ovu vanjsku kocku koja obuhvaca svaku sliku sa tekstom ispod.
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(.white.opacity(0.5))
                        )
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("“It always seems impossible until it’s done.” ")
                            .font(.title2)
                            .fontWeight(.bold)
                        Text("– Nelson Mandela ")
                            .font(.title2)
                            .foregroundColor(.white.opacity(0.5))
                    }
                    .padding(.top, 50)
                    .padding(.bottom, 20)
                }
            }
            .navigationTitle("Statistics for \(monthPick)")
            .navigationBarTitleDisplayMode(.inline)
            .foregroundColor(.white)
            .background(.darkBackground)
            .preferredColorScheme(.dark)
        }
    }
    
    func returnMonthNumber(forMonth monthPick: String) -> Int {
        switch monthPick {
        case "January":
            return 1
        case "February":
            return 2
        case "March":
            return 3
        case "April":
            return 4
        case "May":
            return 5
        case "June":
            return 6
        case "July":
            return 7
        case "August":
            return 8
        case "September":
            return 9
        case "October":
            return 10
        case "November":
            return 11
        default:
            return 12
        }
    }
    
    func addCalories() -> Int {
        var addition = 0
        for food in foods {
            let components = Calendar.current.dateComponents([.month], from: food.dateOfEntry ?? Date.now)
            let month = components.month ?? 0
            if month == returnMonthNumber(forMonth: monthPick) {
                addition += Int(food.numberOfCalories)
            }
        }
        return addition
    }
    
    func exerciseCount() -> Int {
        var lista = [String]()
        for exercise in exercises {
            let components = Calendar.current.dateComponents([.month], from: exercise.dateOfEntry ?? Date.now)
            let month = components.month ?? 0
            if month == returnMonthNumber(forMonth: monthPick) {
                lista.append(exercise.typeOfTraining ?? "")
            }
        }
        return lista.count
    }
    
    func addTime() -> String {
        var hoursAddition = 0
        var minutesAddition = 0
        for exercise in exercises {
            let components = Calendar.current.dateComponents([.month], from: exercise.dateOfEntry ?? Date.now)
            let month = components.month ?? 0
            if month == returnMonthNumber(forMonth: monthPick) {
                hoursAddition += Int(exercise.hoursExercise)
                minutesAddition += Int(exercise.minutesExercise)
            }
        }
        while minutesAddition > 59 {
            hoursAddition += 1
            minutesAddition -= 60
        }
        return "\(hoursAddition)h \(minutesAddition)m"
    }
    
    func exerciseList() -> String {
        var lista = [String]()
        for exercise in exercises {
            let components = Calendar.current.dateComponents([.month], from: exercise.dateOfEntry ?? Date.now)
            let month = components.month ?? 0
            if month == returnMonthNumber(forMonth: monthPick) {
                lista.append(exercise.typeOfTraining ?? "")
            }
        }
        var newList = ""
        for element in lista {
            newList += "\(element), "
        }
        return String((newList == "" ? "Nothing" : newList.dropLast(2)))
    }
    
    static func currentMonth() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM"
        return String(formatter.string(from: Date.now))
    }
}

struct ShowPerMonthView_Previews: PreviewProvider {
    static var previews: some View {
        ShowPerMonthView()
    }
}
