//
//  AddMealData.swift
//  MobilniProjekt
//
//  Created by Duje Popovic on 29.03.2023..
//

import SwiftUI

struct AddMealData: View {
    
    @Environment(\.managedObjectContext) var moc //da mozemo sejvati u model podataka nase podatke
    @Environment(\.dismiss) var dismiss
    
    @State private var dateOfEntry: Date = Date.now
    @State private var numberOfCalories: Int16 = 0
    
    @State private var showAlert: Bool = false
    @State private var titleAlert = ""
    @State private var messageAlert = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section {
                    VStack(alignment: .leading, spacing: 0) {
                        AsyncImage(url: URL(string: "https://upload.wikimedia.org/wikipedia/commons/6/6d/Good_Food_Display_-_NCI_Visuals_Online.jpg"), scale: 3) { image in
                            image
                                .resizable()
                                .scaledToFit()
                        } placeholder: {
                            ProgressView()
                        }
                        .frame(height: 233)
                    }
                    VStack(alignment: .leading, spacing: 0) {
                        Text("Date of entry")
                            .font(.headline)
                        
                        DatePicker("Please enter a time", selection: $dateOfEntry/*, in: Date.now...*/, displayedComponents: .date)
                            .labelsHidden()
                    }
                    
                    VStack(alignment: .leading, spacing: 0) {
                        Text("How many calories did you burn?")
                            .font(.headline)
                        
                        TextField("Enter calories of meal", value: $numberOfCalories, format: .number)
                            .keyboardType(.decimalPad)
                            .padding(.top, 5)
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(.darkBackground)
            .preferredColorScheme(.dark)
            .navigationTitle("Enter meal data")
            .navigationBarTitleDisplayMode(.automatic)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        errorMessages(title: "Save meal", message: "Are you sure you want to save the data?")
                    }
                }
            }
            .alert(titleAlert, isPresented: $showAlert) {
                Button("Cancel", role: .cancel) {}
                Button("Save", role: .none, action: saveData)
            } message: {
                Text(messageAlert)
            }
        }
    }
    func saveData() {
        let newEntry = Food(context: moc)
        
        newEntry.dateOfEntry = dateOfEntry
        newEntry.id = UUID()
        newEntry.numberOfCalories = numberOfCalories
        
        try? moc.save()
        
        dismiss()
    }
    
    func errorMessages(title: String, message: String) {//funkcija za alert
        titleAlert = title
        messageAlert = message
        showAlert = true
    }
}

struct AddMealData_Previews: PreviewProvider {
    static var previews: some View {
        AddMealData()
    }
}
