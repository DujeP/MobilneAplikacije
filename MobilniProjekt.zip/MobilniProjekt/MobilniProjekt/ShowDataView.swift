//
//  ShowDataView.swift
//  MobilniProjekt
//
//  Created by Duje Popovic on 30.03.2023..
//

import SwiftUI

struct ShowDataView: View {
    
    @Environment(\.managedObjectContext) var moc
    @Environment(\.dismiss) var dismiss
    
    @FetchRequest(sortDescriptors: [SortDescriptor(\.dateOfEntry, order: .reverse)], predicate: nil) var foods: FetchedResults<Food>
    
    @FetchRequest(sortDescriptors: [SortDescriptor(\.dateOfEntry, order: .reverse)], predicate: nil) var exercises: FetchedResults<Exercise>
    
    var body: some View {
        NavigationView {
            VStack {
                /*NavigationLink { //samo lipi botun sta san napravija
                    ShowPerMonthView()
                } label: {
                    Text("Search")
                }
                //.padding(12) // mogli smo i ovako
                .frame(width: 80, height: 35)
                .background(.black.opacity(0.5))
                .foregroundColor(.white.opacity(0.9))
                .font(.headline)
                .clipShape(RoundedRectangle(cornerRadius: 30))
                .overlay(//sa overlayon smo dodali ovu vanjsku kocku koja obuhvaca svaku sliku sa tekstom ispod.
                    RoundedRectangle(cornerRadius: 30)
                        .stroke(.white.opacity(0.5))
                )*/
                VStack {
                    Text("Exercises")
                        .font(.title)
                        .bold()
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.bottom)
                    HStack {
                        Text("No.")
                            .frame(maxWidth: .infinity)
                        Text("Training")
                            .frame(maxWidth: .infinity)
                            //.padding(.trailing, 10)
                        Text("Time")
                            .frame(maxWidth: .infinity)
                            .padding(.trailing, 20)
                        Text("Date")
                            .frame(maxWidth: .infinity)
                            .padding(.trailing, 35)
                    }
                }
                
                List {
                    ForEach(exercises) { exercise in
                        HStack {
                            let position = (exercises.firstIndex(of: exercise)!) + 1
                            Text(String(position))
                                .frame(maxWidth: .infinity)
                                .padding(.trailing, 34)
                            Text(exercise.typeOfTraining ?? "N/A")
                                .frame(maxWidth: .infinity)
                                .padding(.trailing, 12)
                            Text("\(exercise.hoursExercise)h \(exercise.minutesExercise)m")
                                .frame(maxWidth: .infinity)
                                .padding(.trailing, 10)
                            Text(exercise.dateOfEntry?.formatted(date: .abbreviated, time: .omitted) ?? "N/A")
                                .frame(maxWidth: .infinity)
                                //.padding(.trailing, 10)
                            /*let components = Calendar.current.dateComponents([.month], from: exercise.dateOfEntry ?? Date.now)
                            let month = components.month
                            Text(String(month ?? 0))*/
                        }
                    }
                    .onDelete(perform: deleteExercises)
                }
                .listStyle(.grouped)
                
                /*Rectangle()
                    .frame(height: 2)
                    .foregroundColor(.secondary)
                    .padding(.vertical)*/
                
                
                VStack {
                    Text("Meals")
                        .font(.title)
                        .bold()
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.bottom)
                    HStack {
                        Text("No.")
                            .frame(maxWidth: .infinity)
                        Text("Calories")
                            .frame(maxWidth: .infinity)
                            .padding(.trailing, 25)
                        Text("Date")
                            .frame(maxWidth: .infinity)
                            .padding(.trailing, 45)
                    }
                }
                List {
                    ForEach(foods) { food in
                        HStack{
                            let position = (foods.firstIndex(of: food) ?? 0) + 1
                            Text(String(position))
                                .frame(maxWidth: .infinity)
                                .padding(.trailing, 34)
                            Text(String(food.numberOfCalories))
                                .frame(maxWidth: .infinity)
                                .padding(.trailing, 25)
                            Text(food.dateOfEntry?.formatted(date: .abbreviated, time: .omitted) ?? "N/A")
                                .frame(maxWidth: .infinity)
                                .padding(.trailing, 15)
                        }
                    }
                    .onDelete(perform: deleteFoods)
                }
                .listStyle(.grouped)
            }
            .scrollContentBackground(.hidden)
            .background(.darkBackground)
            .preferredColorScheme(.dark)
            .navigationTitle("History")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton()
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    NavigationLink {
                        ShowPerMonthView()
                    } label: {
                        Text("Statistics")
                    }
                }
            }
        }
    }
    
    func deleteFoods(at offsets: IndexSet) {
        for offset in offsets {
            let food = foods[offset]
            moc.delete(food)
        }
        
        try? moc.save()
    }
    
    func deleteExercises(at offsets: IndexSet) {
        for offset in offsets {
            let exercise = exercises[offset]
            moc.delete(exercise)
        }
        
        try? moc.save()
    }
}

struct ShowDataView_Previews: PreviewProvider {
    static var previews: some View {
        ShowDataView()
    }
}
