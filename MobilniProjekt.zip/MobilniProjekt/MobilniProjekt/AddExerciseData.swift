//
//  AddExerciseData.swift
//  MobilniProjekt
//
//  Created by Duje Popovic on 29.03.2023..
//

import SwiftUI

struct AddExerciseData: View {
    
    @Environment(\.managedObjectContext) var moc
    @Environment(\.dismiss) var dismiss

    let types = ["Walking", "Jogging", "Swimming", "Biking", "Football", "Gym", "Dancing"]
    
    @State private var typeOfTraining = "Walking"
    @State private var dateOfEntry: Date = Date.now
    @State private var hours: Int16 = 0
    @State private var minutes = 0 //iz nekog razloga kad smo ovo definirali kao Int16 onda nije radija Picker. Ne znam zasto jer ovo povise kad smo definirali sat da je Int16 on je radija bez problema unutar Steppera ali kad se definira minutes kao Int16 onda ne radi u pickeru.
    
    @State private var showAlert: Bool = false
    @State private var titleAlert = ""
    @State private var messageAlert = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section {
                    VStack(alignment: .leading, spacing: 0) {
                        /*AsyncImage(url: URL(string: "https://health.clevelandclinic.org/wp-content/uploads/sites/3/2022/04/exerciseHowOften-944015592-770x533-1.jpg"), scale: 3) { image in
                            image
                                .resizable()
                                .scaledToFit()
                                .clipShape(RoundedRectangle(cornerRadius: 30))
                                .overlay(//sa overlayon smo dodali ovu vanjsku kocku koja obuhvaca svaku sliku sa tekstom ispod.
                                    RoundedRectangle(cornerRadius: 30)
                                        .stroke(.white.opacity(0.5))
                                )
                        } placeholder: {
                            ProgressView()
                        }
                        .frame(height: 233)*/
                        Image("AddExercisePic")
                            .resizable()
                            .scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 30))
                            .overlay(//sa overlayon smo dodali ovu vanjsku kocku koja obuhvaca svaku sliku sa tekstom ispod.
                                RoundedRectangle(cornerRadius: 30)
                                    .stroke(.white.opacity(0.5))
                            )
                            .frame(height: 233)
                    }
                    
                    VStack(alignment: .leading, spacing: 0) {
                        Text("Date of entry")
                            .font(.headline)
                        
                        DatePicker("Please enter a time", selection: $dateOfEntry, in: Date(timeIntervalSinceNow: -259200)...Date.now, displayedComponents: .date)
                            .labelsHidden()
                    }
                    
                    VStack(alignment: .leading, spacing: 0) {
                        Text("How much hours did you exercise")
                            .font(.headline)
                        
                        Stepper(hours == 1 ? "\(hours) hour" : "\(hours) hours", value: $hours, in: 0...10)
                    }
                    
                    VStack(alignment: .leading, spacing: 0) {
                        Picker("How much minutes did you exercise", selection: $minutes){
                            ForEach(0..<60) {
                                Text(minutes == 1 ? "\($0) minute" : "\($0) minutes")
                            }
                        }
                        .pickerStyle(.navigationLink)
                        .font(.headline)
                    }
                    
                    VStack(alignment: .leading, spacing: 0) {//aligment da se tekst pomakne livo sa .leading
                        Text("What kind of exercise did you do?")
                            .font(.headline)
                        
                        Picker("Take your choice", selection: $typeOfTraining) {
                            ForEach(types, id: \.self) {
                                Text($0)
                            }
                        }
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(.darkBackground)
            .preferredColorScheme(.dark)
            .navigationTitle("Enter training data")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        errorMessages(title: "Save exercise", message: "Are you sure you want to save the data?")
                    }
                }
            }
            .alert(titleAlert, isPresented: $showAlert) {
                Button("Cancel", role: .cancel) {}
                Button("Save", role: .none, action: saveData)
            } message: {
                Text(messageAlert)
            }
        }
    }
    func saveData() {
        let newEntry = Exercise(context: moc)
        
        newEntry.id = UUID()
        newEntry.typeOfTraining = typeOfTraining
        newEntry.dateOfEntry = dateOfEntry
        newEntry.hoursExercise = hours
        newEntry.minutesExercise = Int16(minutes)
        
        try? moc.save()
        
        dismiss()
    }
    
    func errorMessages(title: String, message: String) {//funkcija za alert
        titleAlert = title
        messageAlert = message
        showAlert = true
    }
}

struct AddExerciseData_Previews: PreviewProvider {
    static var previews: some View {
        AddExerciseData()
    }
}
